﻿// See https://aka.ms/new-console-template for more information
//Collection:





//ARRAY : fixed sized
string[] kota = { "JKT", "BDG", "SBY" };
int[] nums = { 1, 2, 3, 4 };
int[] nums2 = { 1, 2, 6, 7 };

foreach (int i in nums)
{
    Console.WriteLine(i);
}

kota[1] = "SMG";
foreach(string k in kota)
{
    Console.WriteLine(k);
}

Console.WriteLine();

//linQ method
Console.WriteLine(nums.Average());
Console.WriteLine(nums2.Average());
Console.WriteLine(nums.Sum());
Console.WriteLine(nums2.Sum());

var a = nums.Union(nums2);
var b = nums.Except(nums2); //yang ada di nums tapi ga ada di nums2
var c = nums.Intersect(nums2);

//collection tidak bisa di-Console.Writeline, harus menggunakan looping
foreach (int i in a)
{
    Console.Write(i);
}

Console.WriteLine();

foreach (int i in b)
{
    Console.Write(i);
}

Console.WriteLine();

foreach (int i in c)
{
    Console.Write(i);
}

Console.WriteLine();
Console.WriteLine("------");






//LIST : not fixed size
List<int> intList = new() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
List<string> strList = new();

//mengisi List dengan array
strList.AddRange(kota);
//menambahkan di akhir list
strList.Add("ABC");
//menambahkan di indeks tertentu
strList.Insert(1, "XYZ");
foreach (string i in strList)
{
    Console.Write(i);
}
Console.WriteLine();
//menghapus item berdasarkan item
strList.Remove("ABC");
foreach (string i in strList)
{
    Console.Write(i);
}
Console.WriteLine();

//menghapus item berdasarkan indeks
strList.RemoveAt(1);

foreach(string i in strList)
{
    Console.Write(i);
}