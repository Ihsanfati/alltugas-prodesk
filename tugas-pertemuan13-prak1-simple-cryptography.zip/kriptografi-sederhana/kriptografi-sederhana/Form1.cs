using System.Text;
using Konscious.Security.Cryptography;

namespace kriptografi_sederhana
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String uname = textBox1.Text;
            String pass = textBox2.Text;
            //yang dihash selalu bytes array, bukan bytes string
            byte[] password = Encoding.ASCII.GetBytes(pass);
            //gunakan salt (dalam hal ini tidak random)
            byte[] salt = Encoding.ASCII.GetBytes("rahasia");
            //ambil data dari username
            byte[] userUuidBytes = Encoding.ASCII.GetBytes(uname);

            //buat objek baru untuk menghash password
            var argon2 = new Argon2i(password)
            {
                DegreeOfParallelism = 16,
                MemorySize = 8129,
                Iterations = 40,
                Salt = salt,
                AssociatedData = userUuidBytes
            };
            var hash = argon2.GetBytes(128);
            string hashedValue = Encoding.ASCII.GetString(hash);

            textBox3.Text = hashedValue;    
        }
    }
}