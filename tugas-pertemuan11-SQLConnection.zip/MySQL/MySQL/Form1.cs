namespace MySQL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            string connectionString = "Server=localhost;Database=test;Uid=root;Pwd=;";
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            using (MySqlConnection connection = new MySqlConnection(connectionString)) ;
            connection.Open();

            string query = "SELECT * FROM person";
            List<Person> userLIst = SocketsHttpConnectionContext.Query<Person>(query).ToList();

            dataGridView1.DataSource = userLIst;
            connection.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}