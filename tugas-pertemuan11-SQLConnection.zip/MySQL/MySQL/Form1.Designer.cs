﻿namespace MySQL
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            textBoxPassword = new TextBox();
            textBoxEmail = new TextBox();
            textBoxNama = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            deleteButton = new Button();
            addButton = new Button();
            updateButton = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 12);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(776, 213);
            dataGridView1.TabIndex = 0;
            // 
            // textBoxPassword
            // 
            textBoxPassword.Location = new Point(378, 357);
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.Size = new Size(119, 23);
            textBoxPassword.TabIndex = 1;
            // 
            // textBoxEmail
            // 
            textBoxEmail.Location = new Point(378, 308);
            textBoxEmail.Name = "textBoxEmail";
            textBoxEmail.Size = new Size(119, 23);
            textBoxEmail.TabIndex = 2;
            // 
            // textBoxNama
            // 
            textBoxNama.Location = new Point(378, 263);
            textBoxNama.Name = "textBoxNama";
            textBoxNama.Size = new Size(119, 23);
            textBoxNama.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(312, 271);
            label1.Name = "label1";
            label1.Size = new Size(45, 15);
            label1.TabIndex = 4;
            label1.Text = "Nama: ";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(312, 311);
            label2.Name = "label2";
            label2.Size = new Size(42, 15);
            label2.TabIndex = 5;
            label2.Text = "Email: ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(312, 360);
            label3.Name = "label3";
            label3.Size = new Size(60, 15);
            label3.TabIndex = 6;
            label3.Text = "Password:";
            // 
            // deleteButton
            // 
            deleteButton.Location = new Point(378, 415);
            deleteButton.Name = "deleteButton";
            deleteButton.Size = new Size(50, 23);
            deleteButton.TabIndex = 8;
            deleteButton.Text = "delete";
            deleteButton.UseVisualStyleBackColor = true;
            // 
            // addButton
            // 
            addButton.Location = new Point(312, 415);
            addButton.Name = "addButton";
            addButton.Size = new Size(50, 23);
            addButton.TabIndex = 9;
            addButton.Text = "add";
            addButton.UseVisualStyleBackColor = true;
            // 
            // updateButton
            // 
            updateButton.Location = new Point(442, 415);
            updateButton.Name = "updateButton";
            updateButton.Size = new Size(55, 23);
            updateButton.TabIndex = 10;
            updateButton.Text = "update";
            updateButton.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(updateButton);
            Controls.Add(addButton);
            Controls.Add(deleteButton);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxNama);
            Controls.Add(textBoxEmail);
            Controls.Add(textBoxPassword);
            Controls.Add(dataGridView1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private TextBox textBoxPassword;
        private TextBox textBoxEmail;
        private TextBox textBoxNama;
        private Label label1;
        private Label label2;
        private Label label3;
        private Button deleteButton;
        private Button addButton;
        private Button updateButton;
    }
}