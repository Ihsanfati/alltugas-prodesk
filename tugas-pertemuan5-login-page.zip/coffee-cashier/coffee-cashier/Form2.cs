﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace coffee_cashier
{
    public partial class Form2 : Form
    {
        readonly string username1 = "admin";
        readonly string username2 = "fati";
        readonly string password1 = "admin123";
        readonly string password2 = "fati123";

        public Form2()
        {
            InitializeComponent();
        }

        private void login_Click(object sender, EventArgs e)
        {
            if (username.Text == username1)
            {
                if (password.Text == password1)
                {
                    MessageBox.Show("Selamat datang, Admin !!");
                    Form1 form = new Form1();
                    form.Show();
                    this.Hide();
                }
                else if (password.Text == "")
                {
                    MessageBox.Show("Kolom password wajib diisi !!");
                }
                else
                {
                    MessageBox.Show("Password Anda salah !!");
                }
            }
            else if (username.Text == username2)
            {
                if (password.Text == password2)
                {
                    MessageBox.Show("Selamat datang !!");
                    Form1 form = new Form1();
                    form.Show();
                    this.Hide();
                }
                else if (password.Text == "")
                {
                    MessageBox.Show("Kolom password wajib diisi !!");
                }
                else
                {
                    MessageBox.Show("Password Anda salah !!");
                }
            }
            else if (username.Text == "" | password.Text == "")
            {
                MessageBox.Show("Kolom username dan password wajib diisi !!");
            }
            else
            {
                MessageBox.Show("Username atau password Anda salah !!");
            }
        }

        private void clear_Click(object sender, EventArgs e)
        {
            username.Clear();
            password.Clear();
        }
    }
}
