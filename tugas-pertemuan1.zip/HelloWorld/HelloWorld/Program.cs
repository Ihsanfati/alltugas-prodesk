﻿// See https://aka.ms/new-console-template for more information

//Program HelloWorld Kalkulator

int num1, num2 = 0;

Console.WriteLine("\n");
Console.WriteLine("Hello World Calculator in C#\r");
Console.WriteLine("----------------------------\n");

Console.Write("Masukkan angka pertama: ");
num1 = Convert.ToInt32(Console.ReadLine());

Console.Write("Masukkan angka kedua: ");
num2 = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Opsi operasi: ");
Console.WriteLine("\t a - tambah");
Console.WriteLine("\t s - kurang");
Console.WriteLine("\t m - kali");
Console.WriteLine("\t d - bagi");
Console.Write("Masukkan pilihan (a, s, m, d): ");

switch (Console.ReadLine())
{
    case "a": 
        Console.WriteLine($"Hasil: {num1} + {num2} = " + (num1 + num2)); 
        break;
    case "s":
        Console.WriteLine($"Hasil: {num1} - {num2} = " + (num1 - num2));
        break;
    case "m":
        Console.WriteLine($"Hasil: {num1} x {num2} = " + (num1 * num2));
        break;
    case "d":
        Console.WriteLine($"Hasil: {num1} : {num2} = " + (num1 / num2));
        break;

}

Console.ReadKey();

//hasil pembagian dibelakang koma tidak berfungsi, c merupakan int


