﻿// See https://aka.ms/new-console-template for more information
// CLASS AND OBJECT
class Buku
{
    public string Judul { get; set; } = string.Empty; //nilai default = Empty
    public string Penulis { get; set; } = string.Empty;
    public decimal Harga { get; } //nilai default = 0.0
    public int Stok { get; set; } //nilai default = 0

    //class's constructor (nama methodnya sama persis dengan nama kelas)
    public Buku(string judul, string penulis, decimal harga, int stok)
    {
        Judul = judul;
        Penulis = penulis;
        Harga = harga;
        Stok = stok;
    }
}

class Program
{
    static void Main()
    {
        List<Buku> ListBuku = new()
        {
            new Buku("Book 3 Title", "Bob", 1000m, 10),
            new Buku("Book 1 Title", "Budi", 2000m, 5),
            new Buku("Book 2 Title", "Bob Budi", 3000m, 2)
        };

        //menambahkan buku baru
        ListBuku.Add(new Buku("Book 4 Title", "Bob", 4500m, 4));

        //sortir buku
        ListBuku.Sort((x,y) => x.Judul.CompareTo(y.Judul));

        foreach (var buku in ListBuku)
        {
            Console.WriteLine($"judul: {buku.Judul}, penulis: {buku.Penulis}, harga: {buku.Harga}, stok: {buku.Stok}");
        }

        Console.WriteLine();

        //search buku
        List<Buku> BobBooks = ListBuku.Where(b => b.Penulis == "Bob").ToList(); //nama penulis harus sama persis
        //List<Buku> BobBooks = ListBuku.Where(b => b.Penulis.Contains("Bob")).ToList(); //mencari buku yang ada nama "bob"nya

        foreach (var buku in BobBooks)
        {
            Console.WriteLine($"judul: {buku.Judul}, penulis: {buku.Penulis}, harga: {buku.Harga}, stok: {buku.Stok}");
        }

        //sortir buku berdasarkan harga dengan membuat List baru
        List<Buku> SortedBooks = ListBuku.OrderBy(b => b.Harga).ToList();

        Console.WriteLine();
        foreach (var buku in SortedBooks)
        {
            Console.WriteLine($"judul: {buku.Judul}, penulis: {buku.Penulis}, harga: {buku.Harga}, stok: {buku.Stok}");
        }

        //searching buku dengan method any (return boolean value)
    }
}
