﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace coffee_cashier
{
    public partial class Form3 : Form
    {
        public class User
        {
            public String Username { get; set; }
            public string Password { get; set; }
            public string AccessLevel { get; set; }
        }

        private List<User> userList = new List<User>();
        public Form3()
        {
            InitializeComponent();
        }
        private void HapusBarisByUsername(string username, string password, string accessLevel)
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.Cells["showUsername"].Value.ToString() == username)
                {
                    if (row.Cells["showPassword"].Value.ToString() == password)
                    {
                        if (row.Cells["showAccessLevel"].Value.ToString() == accessLevel)
                        {
                            dataGridView1.Rows.Remove(row);
                            break;
                        } else
                        {
                            MessageBox.Show("Access Level tidak ditemukan !!");
                            break;
                        }
                    } else
                    {
                        MessageBox.Show("Password tidak ditemukan !!");
                        break;
                    }
                } else
                {
                    MessageBox.Show("Username tidak ditemukan !!");
                    break;
                }
            }
        }
        public void SimpanUserList()
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "File Teks|*.txt";
            saveFileDialog.Title = "Simpan User List";
            saveFileDialog.FileName = "UserList.txt";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string fileName = saveFileDialog.FileName;
                using (StreamWriter writer = new StreamWriter(fileName))
                {
                    foreach (User user in userList)
                    {
                        writer.WriteLine("Username: " + user.Username);
                        writer.WriteLine("Password: " + user.Password);
                        writer.WriteLine("Access Level: " + user.AccessLevel);
                        writer.WriteLine();
                    }
                }

                MessageBox.Show("User List telah disimpan pada path: " + fileName, "Informasi");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            User newUser = new User { Username = textBox1.Text, Password = textBox2.Text, AccessLevel = inputAccess.Text };
            userList.Add(newUser);
            dataGridView1.Rows.Add(textBox1.Text, textBox2.Text, inputAccess.Text);
        }

        private void deleteUser_Click(object sender, EventArgs e)
        {
            string userName = textBox1.Text;
            string passWord = textBox2.Text;
            string accessLevels = inputAccess.Text;
            HapusBarisByUsername(userName, passWord, accessLevels);
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            inputAccess.Text = "";
        }

        private void saveUsers_Click(object sender, EventArgs e)
        {
            string fileName = "UsersList.txt"; // Nama file untuk mencetak userList
            SimpanUserList();
        }
    }
}
