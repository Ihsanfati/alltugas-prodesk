﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAPI
{
    internal class Class1 //class customer
    {
        //bangun properti class sesuai dengan atribut-atribut yang ada pada objek customer
        public int id { get; set; }
        public string Nama { get; set; }
        public string Email { get; set; }
        public string Perusahaan { get; set; }

    }
}
