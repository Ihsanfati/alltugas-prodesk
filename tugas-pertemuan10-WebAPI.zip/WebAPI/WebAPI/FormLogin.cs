﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.ApplicationServices;

namespace WebAPI
{
    public partial class FormLogin : Form
    {
        List<Class2> users = new(); //list user dari Class2
        public FormLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string uName = textBox1.Text;
            string Pass = textBox2.Text;

            Class2 user = users.FirstOrDefault(u => u.Email == uName && u.Password == Pass); //u.UserName
            
            if(user != null)
            {
                MessageBox.Show("Selamat datang"); // +user.UserName
            } else
            {
                MessageBox.Show("Login gagal!!");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private async void FormLogin_Load(object sender, EventArgs e)
        {
            //Class2 user = new Class2();
            //user.Id = 0;
            //user.UserName = "admin";
            //user.Password = "1234mimin";
            //user.Level = "admin";
            //users.Add(user);

            using HttpClient client = new();
            string json = await client.GetStringAsync("URL"); //fungsi GetStringAsync() diisi dengan Api yang sudah dibuat

            //deserialisasi = mengubah bentu json ke objek list
            //Class1 users = JsonConvert.DeserializeObject<List<User>>(json); //install library Newtonsoft
        }
    }
}
