﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAPI
{
    internal class Class2 //class user
    {
        public int Id { get; set; }
        //public string UserName { get; set; } = string.Empty;
        public string Email { get; set; }
        public string Password { get; set; } = string.Empty;
        public string Level { get; set; } = string.Empty;
    }
}
