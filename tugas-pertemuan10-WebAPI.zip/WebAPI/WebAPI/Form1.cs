using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace WebAPI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            //buat Web API 

            //buat class baru yang propertinya sama dengan atribut pada Web API

            //Install library newtonsoft.json

            //parsing data JSON menggunakan HttpClient
            using HttpClient client = new();
            string json = await client.GetStringAsync("https://retoolapi.dev/VFa5wi/data"); //fungsi GetStringAsync() diisi dengan Api yang sudah dibuat

            //deserialisasi = mengubah bentu json ke objek list
            Class1 userData = JsonConvert.DeserializeObject<Class1>(json); //install library Newtonsoft
            dataGridView1.DataSource = userData;
        }
    }
}