﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private readonly movieEntities _movieEntities; //entiti database yang dikoneksikan
        public Form1()
        {
            InitializeComponent();
            _movieEntities = new movieEntities();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            loadData();
        }

        private void loadData()
        {
            var movieRecord = _movieEntities.tblMovies.ToList(); //mengambil data dari tabel movie, mengubah ke bentuk list, dan memasukkan ke variabel baru
            dataGridView1.DataSource = movieRecord;

            //memunculkan data ke comboBox
            comboBox1.DataSource = movieRecord;
            comboBox1.DisplayMember = "title"; //hanya menampilkan title
            comboBox1.ValueMember = "id"; //isi title merupakan id
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var newRecord = new tblMovie() //buat objek baru untuk menambahkan data baru
            {
                title = "judul baru",
                genre = "genre baru"
            };
            _movieEntities.tblMovies.Add(newRecord); //simpan ke dalam databases
            _movieEntities.SaveChanges();
            loadData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var idtoDelete = 35;
            var deleteRecord = _movieEntities.tblMovies.FirstOrDefault(q => q.id == idtoDelete); //mencari id yang akan dihapus
            if (deleteRecord != null)
            {
                _movieEntities.tblMovies.Remove(deleteRecord); //hapus dari database
                _movieEntities.SaveChanges();
                loadData();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var idtoUpdate = 5;
            var updateRecord = _movieEntities.tblMovies.FirstOrDefault(q => q.id == idtoUpdate); //mencari id yang akan diupdate
            if(updateRecord != null)
            {
                updateRecord.title = "Ihsan Fadli";
                updateRecord.genre = "Cakasen no 2";
                _movieEntities.SaveChanges();
                loadData();
            }
        }
    }
}
